# Changelog

Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning: [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.1.0-dev] - 2026-10-30

### Added
- Direct virtual production from per-product YAML, including all 36 reference mob IDs
  (40 bundled defaults), ranges, stack-scaled capacities, metadata and purchase prices.
- Configurable gameplay menus, storage cell withdrawals, purchases, corruption puzzle,
  recent audit viewer, Bedrock layouts and viewer-specific PlaceholderAPI resolution.
- Sell wands with authenticated modifiers, finite uses and day-based expiry.
- Typed timed boosters, passive personal XP/cash effects and booster item grants.
- Calendar/weighted global events, XP/cash multipliers and configurable restrictions.
- Real typed EssentialsX, ShopGUI+ and EconomyShopGUI price sources; WorldGuard checks.
- MongoDB backend using Braven schema v1; no original database migration is claimed.

### Fixed
- Startup/checkpoint gating, explicit deletion tombstones and queued SQL writes.
- Quote/payment/drain synchronization, payout-result handling and dirty stock marking.
- Logical storage without per-vanilla-stack allocation; safe overflow restoration.
- Native spawner duplication, item count truncation after lowered limits, menu callback
  leakage, and world/entity scheduling in restoration, holograms, Ninja and hoppers.

### Qualification
- Automated tests and a shaded JAR are verified separately from live Paper/Folia,
  shop/economy plugins and database servers. See docs/FEATURE_PARITY.md.

## [1.0.2] - 2026-10-30

### Fixed
- Booster sweep used `Bukkit.getScheduler()`, which does not exist on Folia.
  It now runs on the global region scheduler.
- Shaded libraries were relocated into the pre-rename package because a stale
  incremental artifact survived `clean`; a full rebuild now produces
  `dev.yanianz.bravenspawner.libs.*` only.

## [1.0.1] - 2026-10-30

### Fixed
- GUI lock gates are now enforced on open and released on close: `canOpen`,
  `markOpened` and `markClosed` are called from the inventory path, so the
  reconnect cooldown and the post-close save lock actually apply.
- Page navigation inside one spawner no longer re-triggers the cooldown.

### Changed
- Gradle wrapper committed; CI builds through `./gradlew`.

## [1.0.0] - 2026-10-30

### Added
- Sell service: per-material pricing, multiplier, autosell, notifications switch.
- Shop hook: `hooks.yml` selection with clear logs when a plugin is absent.
- Ninja spawners: per-player block invisibility by distance.
- Hopper integration: virtual storage feeding a hopper beneath the block.
- Mending: stored XP repairs the breaking tool when enabled.
- Restore-missing: spawner records survive world rollbacks.
- Corruption: random countdown, production halt, radius repair.
- GUI guards: reconnect cooldown, post-close lock, teleport auto-close.

## [1.0.0] - 2026-10-30

### Added
- Virtual spawners with per-tier interval and stack batching.
- Storage tiers, unlimited mode, paged chest GUI.
- Ownership, per-spawner trust, `/vmodify`.
- Economy: purchase, upgrades, Vault integration.
- Boosters: player and spawner multipliers.
- Holograms on TextDisplay, no external dependency.
- Persistence: YAML, SQLite (WAL), MySQL — one interface, transactional flush.
- Paper region scheduler throughout; Folia supported.

[Unreleased]: https://github.com/YanIanZ/BravenSpawner/compare/v1.0.2...HEAD
[1.0.2]: https://github.com/YanIanZ/BravenSpawner/releases/tag/v1.0.2
[1.0.1]: https://github.com/YanIanZ/BravenSpawner/releases/tag/v1.0.1
[1.0.0]: https://github.com/YanIanZ/BravenSpawner/releases/tag/v1.0.0
