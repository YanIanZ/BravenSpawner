# BravenSpawner

> **Development status (2026-10-30):** feature recreation is in progress against the supplied VirtualSpawner 7.2.0-rc-12 JAR. The verified continuation lives in an isolated workspace because another agent session is editing the original checkout. See [feature parity](docs/FEATURE_PARITY.md), [the audit](docs/AUDIT.md), and [verification](docs/VERIFICATION.md). Compilation and unit tests do not establish Paper/Folia runtime compatibility.

Virtual spawners for **Paper** and **Folia** — stacking, chest-GUI storage, upgrades,
boosters, corruption and multi-backend persistence.

[![Build](https://github.com/YanIanZ/BravenSpawner/actions/workflows/build.yml/badge.svg)](https://github.com/YanIanZ/BravenSpawner/actions/workflows/build.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Paper](https://img.shields.io/badge/Paper-1.20%E2%80%931.21-blue)](https://papermc.io)
[![Folia](https://img.shields.io/badge/Folia-supported-brightgreen)](https://papermc.io/software/folia)
[![Java](https://img.shields.io/badge/Java-21-orange)](https://adoptium.net)

## What it does

A spawner block becomes a self-contained production unit. It generates configured mob loot or
item products directly on a timer, banks the output in its own storage, and hands it back
through a paged chest GUI. The current implementation keeps generated output in memory and stores it using the selected backend; periodic crash-durable checkpoints and full Folia thread-ownership verification are **planned**, not yet verified.

```
place spawner ──▶ tick (tier interval) ──▶ produce (stack × cycle)
      │                                          │
      │                                          ▼
      └─ right-click ──▶ GUI ──▶ withdraw ◀── stored loot
```

## Features

| Area | What you get |
|---|---|
| **Production** | mob spawners and item generators, per-tier interval, stack multiplier |
| **Storage** | virtual quantities per item identity, product/stack capacities, unlimited mode, paged GUI |
| **Stacking** | shift-right-click to merge up to `stack-limit`, per-chunk cap |
| **Economy** | Vault sell/autosell, product purchase prices, player-aware shop prices and atomic stock settlement |
| **Corruption** | random countdown, ordered configurable repair puzzle, player-centered repair radius, production halt |
| **Protection** | ownership/trust, reconnect cooldown, lock timeout and teleport guard; some input paths require security fixes |
| **World rules** | blacklist, activation radius, silk-touch, explosion guard and durability settings |
| **Visuals** | configured multiline TextDisplay holograms (no external hologram plugin required) |
| **Persistence** | YAML, SQLite, MySQL or MongoDB; queued dirty checkpoints and fail-closed loading |
| **Scheduling** | Paper region API is used in core paths, but some legacy/global usages still need Folia safety fixes |

## Compatibility

| | |
|---|---|
| Server | Built against Paper API 1.21.1; other versions/Folia require runtime validation |
| Java | 21 for current build; newer Paper API versions may require Java 25 |
| Optional | Vault, PlaceholderAPI, Floodgate/Geyser, WorldGuard, EssentialsX, ShopGUI+, EconomyShopGUI |

## Install

```bash
# build
./gradlew build
# → build/libs/BravenSpawner.jar
```

Drop the jar in `plugins/`, start the server, edit `plugins/BravenSpawner/config.yml`,
then `/bspawner give ZOMBIE`. Original command aliases are retained; permission names use `bravenspawner.*`.

## Commands

| Command | Permission | Purpose |
|---|---|---|
| `/vspawner give <mob\|item:ID> [player] [stack]` | `bravenspawner.admin` | hand out a spawner item |
| `/vspawner list` | `bravenspawner.admin` | your spawners, stacks and stored totals |
| `/vspawner reload` | `bravenspawner.admin` | reload config, rebuild schedules |
| `/vspawner booster <player> <mult> [sec]` | `bravenspawner.admin` | grant a production multiplier |
| `/vspawner menu` | `bravenspawner.admin` | open the GUI for your nearest spawner |
| `/vspawner corrupt\|repair` | `bravenspawner.admin` | drive the corruption system |
| `/vmodify <player>` | `bravenspawner.use` | toggle trust on the spawner you look at |
| `/shtoggle` | `bravenspawner.use` | toggle holograms on your spawners |

## Configuration

Configuration files created on first run:

```
config.yml      production, stacking, economy, corruption, holograms, mobs, items
databases.yml   YAML | SQLITE | MYSQL, pool size, credentials
hooks.yml       currency and shop integration selection
mobs/*.yml      40 mob product defaults; legacy local catalogues migrate once
itemspawners/   item product definitions
gui/*.yml       main/storage/purchase/corruption/log layouts
boosters/       normal timed effects and carried personal items
sellwand.yml    sell wand behavior and lifetimes
modifiers.yml   authenticated wand modifiers
sounds.yml      feedback
holograms.yml   text and display settings
other/          scheduled events and restricted product types
```

Every switch in `config.yml` is documented inline. The full surface is large by
design — a server that wants only "spawn mobs, store loot" can leave everything
else at defaults.

## Architecture and upgrade documentation

The [architecture guide](docs/ARCHITECTURE.md) distinguishes implemented code from the target design. The [documentation hub](docs/README.md) links the [source audit](docs/AUDIT.md), [PRD](docs/PRD.md), [technical specification](docs/TECHNICAL_SPEC.md), [roadmap](docs/ROADMAP.md), [migration guide](docs/MIGRATION.md), and [owner test plan](docs/TESTER_OWNER.md). These describe **proposed** work, not shipped features.

```
BravenSpawner       boot order: config → storage → manager → subsystems → load
manager/            one tick pass, per-spawner region schedule
storage/            interface + YAML / SQLite / MySQL, Codec for items
gui/                sessions, click-cancel by construction
listener/           block lifecycle, death routing, guards
mechanics/          ninja invisibility, hoppers, mending, restore-missing
corruption/         countdown scheduler
sell/               valuation, autosell, shop hooks
util/               Schedulers (Paper region API), Text/money formatter
```

Target design principles (not all guaranteed by current v1.0.1):

1. **Thread ownership.** All world/entity operations must obey Paper/Folia scheduler rules.
2. **Fail closed.** Failed loads, invalid items and rejected transactions cannot mutate authoritative stock.
3. **Single-owner invariants.** Lifecycle, inventory and economy mutation must be coordinated atomically.
4. **GUI/session integrity.** Only an active verified inventory session may issue a mutation.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Issues and pull requests are welcome;
The continuation adds automated tests for storage, transactions, menus, events, boosters and provider routing.

## Security

See [SECURITY.md](SECURITY.md) for reporting vulnerabilities.

## License

[MIT](LICENSE) © 2026 YanIanZ

BravenSpawner is an independent implementation. It is not affiliated with,
endorsed by, or derived from the source of any commercial spawner plugin.

## Continuation commands and behavior

`/bspawner sellwand <player> [uses|Nd|inf] [amount]` grants a wand;
`/bspawner modifier <player> <type> <value> [amount]` grants a cursor-applied modifier.
`/bspawner boosteritem <player> <normal|personal> <id> [amount]` grants a configured booster.
Normal effects activate on a spawner; personal XP/cash items work while carried.
Timed effects currently reset after restart.

Virtual output is aggregated by item identity, so large quantities do not allocate one
inventory slot for every vanilla stack. Collect or sell stored items before breaking
a spawner. Remaining XP is returned after optional Mending. Product restrictions can
lock menus or allow selling while blocking raw withdrawals; the bypass permission is
`bravenspawner.restrictions.bypass` (operator by default).

Shop prices come from the selected configured provider, with local product/global
prices as fallback when the provider has no quote. An explicit local zero price
blocks local selling; a configured external shop can supply its own price. Provider
stock limits, taxes and special currencies are not processed as shop transactions.
Only Vault settlement is implemented. WorldGuard is the implemented claim API;
other land plugins still require qualification or adapters.

Full parity is **not complete**: legacy server versions, the original binary API,
reference database migration, additional currency/shop/land providers, ItemsAdder
metadata and remaining visual effects are tracked in the parity report.
